# 封顶规则：`wrong_or_shallow_evidence_mix`

## 触发条件

复合任务需要多源证据，但最终答案使用错误、浅层或不匹配的信息源，导致分析基础不足。

典型表现：
- 深度调研只给提纲，没有市场规模、份额、技术路线、产品节奏或 A 股映射细节
- 新闻影响评估列出低相关热点，缺少核心标的公告、政策或舆论
- 产业链利润弹性只讲概念，不给价值量、成本占比、盈利贡献或估值
- 历史事件传导只套模板，没有对本次事件做量化验证

## 分数上限

`score_ceiling = 60`

## 不触发条件

- 用户只要求方向性框架，且答案明确说明证据层级和局限。
- 信息源本身可用但缺乏综合判断和传导路径（应由 `information_pile_without_synthesis` 覆盖）。

## 与 `information_pile_without_synthesis` 的边界

本规则聚焦"信息源本身质量不足"，即证据基础问题；`information_pile_without_synthesis` 聚焦"信息量充足但缺乏综合判断"，即信息拼盘问题。若两者同时存在，按更严重者封顶，不叠加。

## 关联维度

- `multi_source_evidence_integration`
- `data_logic_rigor`
- `tool_usage`
