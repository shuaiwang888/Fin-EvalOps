# 封顶规则：`stale_or_wrong_time_evidence`

分数上限：`50`

当题目强依赖时效，但答案使用过时信息、错误时间窗口或旧消息解释当前行情时触发。

触发条件：
- 用户问“最新消息、最近一两天、今天、为什么上涨/下跌”，答案主要使用过时材料
- 明确日期、报告期、交易日或历史区间被锚定错误
- 消息面问题回答的是背景知识或长期政策，而不是近期能影响股价的信息

不触发条件：
- 长期价值分析中使用历史材料作为背景，且未冒充最新消息。

根因优先映射：
- `evidence.time-scope-mismatch`
- `evidence.stale-key-evidence`
- `tool.missing-recency-search`
