# 封顶规则：`overconfident_or_unsuitable_action`

分数上限：`55`

当答案给出过度确定或明显不适当的行动建议，可能诱导用户承担与画像或处境不匹配的风险时触发。

触发条件：
- 使用确定性底部、必涨、稳赚、一定反弹、明确回本时间等表达。
- 对高风险、短线、主题、单一行业或单一股票推荐缺少仓位和适用人群边界。
- 对低风险、亏损、迷茫或深套用户推荐高波动集中仓位。
- 对加仓、抄底、追涨给强建议，但没有证伪条件、止损/止盈、分批节奏或回撤容忍。

不触发条件：
- 答案给出明确但条件化的建议，并充分说明风险、仓位、期限和证伪条件。
- 答案因信息不足不直接给确定结论，但提供了可执行的分层决策框架。

根因优先映射：
- `reasoning.risk-state-mishandled`
- `reasoning.unsuitable-personalization`
- `composition.fact-opinion-boundary-blurred`
