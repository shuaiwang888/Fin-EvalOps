# 封顶规则：`missed_core_investment_logic`

分数上限：`60`

当答案没有抓住题目的核心投资逻辑时触发。

触发条件：
- 行情归因只讲涨跌、资金或技术面，没有解释本质驱动
- 题材股分析没有讲题材是什么、何时发酵、级别、空间和持续性
- 价值股分析没有讲商业模式、盈利逻辑或估值是否便宜
- 对比/切换问题没有给出核心差异和切换理由
- 隐含资产、客户结构、订单或题材纯度才是市场定价核心时，答案只按传统财务或技术面解释

不触发条件：
- 答案抓住核心逻辑，但证据或量化不足。此时只在对应维度扣分。

根因优先映射：
- `reasoning.no-investment-thesis`
- `reasoning.broken-causal-chain`
- `intent.hidden-investment-need-missed`
